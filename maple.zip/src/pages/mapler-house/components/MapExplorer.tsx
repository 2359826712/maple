import { Fragment, useEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { mapLocations, monsterImages } from '@/mocks/mapler-house';

type MajorRegion = 'maple' | 'arcane' | 'grandis';
type SortKey = 'level' | 'exp' | 'meso' | 'spawn' | 'name';

type MapLocation = {
  name: string;
  mapId: number;
  minLevel: number;
  maxLevel: number;
  monsters: string[];
  burning: number;
  version: string;
  image: string;
  imageSource?: string;
};

type MapleStoryIoMap = {
  id: number;
  streetName: string;
  name: string;
};

type MapExpansionRule = {
  street: string;
  minLevel: number;
  maxLevel: number;
  limit: number;
  monsters: string[];
  version?: string;
};

type TableRow = MapLocation & {
  majorRegion: MajorRegion;
  zone: string;
  mapName: string;
  avgLevel: number;
  forceLabel: string;
  spawn: number;
  capPerGen: number;
  expHour: number;
  mesoHour: number;
  hoursLevel: number;
};

type MapLabel = { label: string; x: number; y: number; tone?: 'light' | 'dark' };
type MapPin = { zone: string; x: number; y: number; count: number };

const MAP_API_REGION = 'GMS';
const MAP_API_VERSION = '253';
const MAP_IMAGE_SOURCE = 'MapleStory.io GMS v253 map render';
const MAPLEMAPS_TABLE_URL = 'https://maplemaps.net/map-table';
const MAPLEMAPS_WORLD_URL = 'https://maplemaps.net/world-map/?worldMap=WorldMap&parentWorld=';
const mapRender = (mapId: number) => `https://maplestory.io/api/${MAP_API_REGION}/${MAP_API_VERSION}/map/${mapId}/render?showPortals=true&showLife=true`;

const expandedMapRules: MapExpansionRule[] = [
  { street: 'Reverse City', minLevel: 205, maxLevel: 215, limit: 28, monsters: ['Reverse City Mob', 'Research Train Mob'] },
  { street: 'Chu Chu Island', minLevel: 210, maxLevel: 220, limit: 24, monsters: ['Chu Chu Mob', 'Hungry Muto Mob'] },
  { street: 'Yum Yum Island', minLevel: 215, maxLevel: 225, limit: 26, monsters: ['Yum Yum Mob', 'Illiard Mob'] },
  { street: 'Lachelein', minLevel: 220, maxLevel: 230, limit: 32, monsters: ['Dreamkeeper', 'Nightmare Mob'] },
  { street: 'Arcana', minLevel: 225, maxLevel: 240, limit: 36, monsters: ['Spirit of Arcana', 'Forest Spirit'] },
  { street: 'Morass', minLevel: 230, maxLevel: 245, limit: 34, monsters: ['Morass Mob', 'Swamp Spirit'] },
  { street: 'Esfera', minLevel: 235, maxLevel: 250, limit: 42, monsters: ['Esfera Mob', 'Light Seeker'] },
  { street: 'Moonbridge', minLevel: 245, maxLevel: 255, limit: 36, monsters: ['Moonbridge Mob', 'Void Creature'] },
  { street: 'Labyrinth of Suffering', minLevel: 250, maxLevel: 260, limit: 28, monsters: ['Labyrinth Mob', 'Suffering Guard'] },
  { street: 'Limina', minLevel: 255, maxLevel: 270, limit: 64, monsters: ['Ascendion', 'Foreberion'] },
  { street: 'Cernium', minLevel: 260, maxLevel: 275, limit: 32, monsters: ['Adept of Light', 'Scholar Ghost'] },
  { street: 'Burning Cernium', minLevel: 265, maxLevel: 280, limit: 28, monsters: ['Burning Cernium Mob', 'Holy Knight'] },
  { street: 'Hotel Arcus', minLevel: 270, maxLevel: 280, limit: 32, monsters: ['Desperate Thief', 'Steel Xenoroid'] },
  { street: 'Odium', minLevel: 275, maxLevel: 285, limit: 32, monsters: ['Blinded Soldier', 'Blinded Mage'] },
  { street: 'Shangri-La', minLevel: 280, maxLevel: 290, limit: 42, monsters: ['Spring Spirit', 'Autumn Spirit'] },
  { street: 'Arteria', minLevel: 280, maxLevel: 295, limit: 34, monsters: ['Arteria Mob', 'High Flora Guard'] },
  { street: 'Carcion', minLevel: 285, maxLevel: 300, limit: 46, monsters: ['Carcion Mob', 'Abyss Creature'] },
  { street: 'Commerci Republic', minLevel: 160, maxLevel: 210, limit: 40, monsters: ['Grosso Polpo', 'Aqua Patrol'], version: 'gms' },
  { street: 'Shaolin Temple', minLevel: 250, maxLevel: 275, limit: 24, monsters: ['扫地僧', '铜人'], version: 'cms' },
  { street: 'Orbis', minLevel: 50, maxLevel: 90, limit: 34, monsters: ['Cloud Mob', 'Sky Sentinel'], version: 'all' },
  { street: 'El Nath', minLevel: 70, maxLevel: 120, limit: 34, monsters: ['Snowfield Mob', 'Ice Sentinel'], version: 'all' },
  { street: 'Ludibrium', minLevel: 90, maxLevel: 130, limit: 40, monsters: ['Toy Mob', 'Clocktower Mob'], version: 'all' },
  { street: 'Leafre', minLevel: 100, maxLevel: 160, limit: 36, monsters: ['Dragon Forest Mob', 'Minar Mob'], version: 'all' },
  { street: 'Temple of Time', minLevel: 140, maxLevel: 200, limit: 36, monsters: ['Memory Guardian', 'Oblivion Guardian'], version: 'all' },
  { street: 'Kritias', minLevel: 170, maxLevel: 210, limit: 36, monsters: ['Kritias Soldier', 'Fallen Mage'], version: 'all' },
  { street: 'Zipangu', minLevel: 160, maxLevel: 280, limit: 40, monsters: ['侍大将', '忍者'], version: 'jms' },
];

const excludedMapName = /(cutscene|quest|hidden|entrance|exit|practice|tutorial|event|cash|shop|storage|station|somewhere|safe zone|preview|test|theater|saloon|town)$/i;

const buildExpandedMaps = (apiMaps: MapleStoryIoMap[], featuredMaps: MapLocation[]) => {
  const usedMapIds = new Set(featuredMaps.map((map) => map.mapId));
  const expandedMaps: MapLocation[] = [];

  expandedMapRules.forEach((rule) => {
    const matches = apiMaps
      .filter((map) => map.streetName === rule.street)
      .filter((map) => map.id < 900000000 && !usedMapIds.has(map.id) && !excludedMapName.test(map.name))
      .slice(0, rule.limit);

    matches.forEach((map, index) => {
      usedMapIds.add(map.id);
      expandedMaps.push({
        name: `${map.streetName} — ${map.name}`,
        mapId: map.id,
        minLevel: rule.minLevel,
        maxLevel: rule.maxLevel,
        monsters: rule.monsters,
        burning: index % 5 === 0 ? 10 : index % 3 === 0 ? 8 : 6,
        version: rule.version || 'all',
        imageSource: MAP_IMAGE_SOURCE,
        image: mapRender(map.id),
      });
    });
  });

  return expandedMaps;
};

const regionOptions: Array<{ key: MajorRegion; label: string; hint: string }> = [
  { key: 'maple', label: 'Maple World Region', hint: 'Pre-260 and overseas areas' },
  { key: 'arcane', label: 'Arcane River Region', hint: 'Lv. 200-259 training maps' },
  { key: 'grandis', label: 'Grandis Region', hint: 'Lv. 260+ Sacred Force maps' },
];

const worldMapLabels: Record<MajorRegion, MapLabel[]> = {
  maple: [
    { label: 'Maple Island', x: 22, y: 20 },
    { label: 'Victoria Island', x: 15, y: 40, tone: 'light' },
    { label: 'Orbis', x: 48, y: 30 },
    { label: 'El Nath Mts.', x: 59, y: 39 },
    { label: 'Ludus Lake', x: 43, y: 68 },
    { label: 'Ossyria', x: 65, y: 60, tone: 'light' },
    { label: 'Mu Lung Garden', x: 84, y: 63 },
    { label: 'Nihal Desert', x: 64, y: 80 },
    { label: 'Minar Forest', x: 31, y: 82 },
    { label: 'Temple of Time', x: 13, y: 88 },
    { label: 'Commerci', x: 9, y: 26 },
    { label: 'Zipangu', x: 8, y: 16 },
  ],
  arcane: [
    { label: 'Vanishing Journey', x: 18, y: 34 },
    { label: 'Chu Chu Island', x: 35, y: 52 },
    { label: 'Lachelein', x: 50, y: 34 },
    { label: 'Arcana', x: 63, y: 55 },
    { label: 'Morass', x: 75, y: 37 },
    { label: 'Esfera', x: 82, y: 60 },
    { label: 'Moonbridge', x: 38, y: 77 },
    { label: 'Labyrinth', x: 56, y: 76 },
    { label: 'Limina', x: 72, y: 78, tone: 'light' },
  ],
  grandis: [
    { label: 'Cernium', x: 18, y: 33 },
    { label: 'Burning Cernium', x: 29, y: 42 },
    { label: 'Hotel Arcus', x: 44, y: 58 },
    { label: 'Odium', x: 58, y: 41 },
    { label: 'Shangri-La', x: 70, y: 54 },
    { label: 'Arteria', x: 82, y: 34 },
    { label: 'Carcion', x: 82, y: 70 },
    { label: 'Tallahart', x: 50, y: 78 },
    { label: 'Solerian', x: 36, y: 28 },
  ],
};

const getZone = (name: string) => name.split('—')[0]?.trim() || name.split('-')[0]?.trim() || 'Other';
const getMapName = (name: string) => name.split('—')[1]?.trim() || name;

const getMajorRegion = (map: MapLocation): MajorRegion => {
  const zone = getZone(map.name).toLowerCase();
  if (['cernium', 'burning cernium', 'hotel arcus', 'odium', 'shangri-la', 'arteria', 'tallahart', 'solerian', 'carsion', 'carcion', '카르시온'].some((name) => zone.includes(name))) {
    return 'grandis';
  }
  if (['limina', 'arcane river', 'vanishing', 'reverse city', 'chu chu', 'yum yum', 'lachelein', 'arcana', 'morass', 'esfera', 'moonbridge', 'labyrinth'].some((name) => zone.includes(name))) return 'arcane';
  return 'maple';
};

const getZonePosition = (zone: string, region: MajorRegion, index: number): { x: number; y: number } => {
  const normalized = zone.toLowerCase();
  const known: Record<string, { x: number; y: number }> = {
    commerci: { x: 9, y: 24 },
    '天空之城': { x: 46, y: 26 },
    '少林寺': { x: 90, y: 52 },
    '倭城': { x: 12, y: 17 },
    limina: { x: 72, y: 78 },
    cernium: { x: 18, y: 33 },
    'hotel arcus': { x: 44, y: 58 },
    odium: { x: 58, y: 41 },
    'shangri-la': { x: 70, y: 54 },
    arteria: { x: 82, y: 34 },
    solerian: { x: 36, y: 28 },
    carsion: { x: 82, y: 70 },
    carcion: { x: 82, y: 70 },
    '카르시온': { x: 82, y: 70 },
    'reverse city': { x: 22, y: 42 },
    'yum yum island': { x: 39, y: 57 },
    moonbridge: { x: 38, y: 77 },
    'labyrinth of suffering': { x: 56, y: 76 },
  };

  const match = Object.entries(known).find(([key]) => normalized.includes(key.toLowerCase()) || zone.includes(key));
  if (match) return match[1];

  const label = worldMapLabels[region][index % worldMapLabels[region].length];
  return { x: label.x, y: label.y };
};

const formatRate = (value: number) => {
  if (value >= 1000) return `${(value / 1000).toFixed(1)}T`;
  return `${Math.round(value)}B`;
};

const monsterMarkerPositions = [
  { x: 10, y: 73 }, { x: 16, y: 36 }, { x: 23, y: 35 }, { x: 30, y: 48 },
  { x: 20, y: 67 }, { x: 28, y: 67 }, { x: 41, y: 76 }, { x: 49, y: 74 },
  { x: 58, y: 58 }, { x: 65, y: 57 }, { x: 72, y: 58 }, { x: 78, y: 56 },
  { x: 86, y: 57 }, { x: 93, y: 57 }, { x: 61, y: 36 }, { x: 68, y: 35 },
  { x: 76, y: 36 }, { x: 83, y: 44 }, { x: 91, y: 43 }, { x: 66, y: 75 },
  { x: 74, y: 75 }, { x: 82, y: 76 }, { x: 89, y: 76 }, { x: 35, y: 76 },
];

const platformBands = [
  { left: 4, top: 79, width: 92 },
  { left: 6, top: 59, width: 30 },
  { left: 52, top: 51, width: 43 },
  { left: 7, top: 35, width: 27 },
  { left: 62, top: 29, width: 31 },
  { left: 58, top: 71, width: 35 },
];

const toRow = (map: MapLocation): TableRow => {
  const avgLevel = Math.round((map.minLevel + map.maxLevel) / 2);
  const majorRegion = getMajorRegion(map);
  const spawn = Math.max(24, Math.round((map.maxLevel - map.minLevel) * 1.2 + map.monsters.length * 6 + map.burning + 18));
  const capPerGen = Math.max(20, spawn - Math.round(map.monsters.length * 1.5));
  const expHour = Math.round((avgLevel * spawn * (1 + map.burning / 100)) / 2.6);
  const mesoHour = Math.round((avgLevel * spawn * 0.18) / 10);
  const forceLabel = majorRegion === 'grandis' ? `Sac ${Math.max(30, (avgLevel - 250) * 10)}` : majorRegion === 'arcane' ? `Arc ${Math.max(60, (avgLevel - 190) * 4)}` : '-';

  return {
    ...map,
    majorRegion,
    zone: getZone(map.name),
    mapName: getMapName(map.name),
    avgLevel,
    forceLabel,
    spawn,
    capPerGen,
    expHour,
    mesoHour,
    hoursLevel: Math.max(0.2, Number((300 / Math.max(1, expHour)).toFixed(1))),
  };
};

export default function MapExplorer() {
  const { t } = useTranslation();
  const [selectedRegion, setSelectedRegion] = useState<MajorRegion>('maple');
  const [selectedZone, setSelectedZone] = useState('all');
  const [query, setQuery] = useState('');
  const [level, setLevel] = useState(275);
  const [showFrenzy, setShowFrenzy] = useState(false);
  const [personalRates, setPersonalRates] = useState(true);
  const [sortKey, setSortKey] = useState<SortKey>('level');
  const [selectedMapName, setSelectedMapName] = useState<string | null>(null);
  const [expandedMaps, setExpandedMaps] = useState<MapLocation[]>([]);
  const [isLoadingExpandedMaps, setIsLoadingExpandedMaps] = useState(true);
  const [mapLoadError, setMapLoadError] = useState<string | null>(null);

  useEffect(() => {
    let isActive = true;

    const loadExpandedMaps = async () => {
      setIsLoadingExpandedMaps(true);
      setMapLoadError(null);

      try {
        const response = await fetch(`https://maplestory.io/api/${MAP_API_REGION}/${MAP_API_VERSION}/map`);
        if (!response.ok) throw new Error(`MapleStory.io returned ${response.status}`);

        const apiMaps = await response.json() as MapleStoryIoMap[];
        if (!isActive) return;

        setExpandedMaps(buildExpandedMaps(apiMaps, mapLocations as MapLocation[]));
      } catch (error) {
        if (!isActive) return;
        setExpandedMaps([]);
        setMapLoadError(error instanceof Error ? error.message : 'Could not load live map list');
      } finally {
        if (isActive) setIsLoadingExpandedMaps(false);
      }
    };

    loadExpandedMaps();

    return () => {
      isActive = false;
    };
  }, []);

  const allMaps = useMemo(() => [...(mapLocations as MapLocation[]), ...expandedMaps], [expandedMaps]);
  const rows = useMemo(() => allMaps.map(toRow), [allMaps]);
  const regionRows = useMemo(() => rows.filter((row) => row.majorRegion === selectedRegion), [rows, selectedRegion]);
  const zones = useMemo(() => ['all', ...Array.from(new Set(regionRows.map((row) => row.zone)))], [regionRows]);

  const filteredRows = useMemo(() => {
    const normalized = query.trim().toLowerCase();

    return regionRows
      .filter((row) => selectedZone === 'all' || row.zone === selectedZone)
      .filter((row) => {
        if (!normalized) return true;
        return [row.name, row.zone, row.mapName, row.forceLabel, ...row.monsters]
          .some((value) => value.toLowerCase().includes(normalized));
      })
      .map((row) => {
        const frenzyMultiplier = showFrenzy ? 1.35 : 1;
        const personalMultiplier = personalRates ? Math.max(0.75, 1 - Math.abs(row.avgLevel - level) * 0.015) : 1;
        return {
          ...row,
          spawn: Math.round(row.spawn * frenzyMultiplier),
          expHour: Math.round(row.expHour * frenzyMultiplier * personalMultiplier),
          mesoHour: Math.round(row.mesoHour * frenzyMultiplier),
          hoursLevel: Math.max(0.2, Number((300 / Math.max(1, row.expHour * frenzyMultiplier * personalMultiplier)).toFixed(1))),
        };
      })
      .sort((a, b) => {
        if (sortKey === 'exp') return b.expHour - a.expHour;
        if (sortKey === 'meso') return b.mesoHour - a.mesoHour;
        if (sortKey === 'spawn') return b.spawn - a.spawn;
        if (sortKey === 'name') return a.mapName.localeCompare(b.mapName);
        return a.avgLevel - b.avgLevel || b.expHour - a.expHour;
      });
  }, [level, personalRates, query, regionRows, selectedZone, showFrenzy, sortKey]);

  const selectedMap = useMemo(
    () => filteredRows.find((row) => row.name === selectedMapName) || filteredRows[0],
    [filteredRows, selectedMapName],
  );

  const selectRelativeMap = (direction: -1 | 1) => {
    if (filteredRows.length === 0) return;
    const currentIndex = filteredRows.findIndex((row) => row.name === selectedMapName);
    const baseIndex = currentIndex >= 0 ? currentIndex : 0;
    const nextIndex = (baseIndex + direction + filteredRows.length) % filteredRows.length;
    setSelectedMapName(filteredRows[nextIndex].name);
  };

  const mapPins = useMemo<MapPin[]>(
    () =>
      zones
        .filter((zone) => zone !== 'all')
        .map((zone, index) => {
          const position = getZonePosition(zone, selectedRegion, index);
          return {
            zone,
            x: position.x,
            y: position.y,
            count: regionRows.filter((row) => row.zone === zone).length,
          };
        }),
    [regionRows, selectedRegion, zones],
  );

  const currentRegion = regionOptions.find((region) => region.key === selectedRegion) || regionOptions[0];

  return (
    <div className="space-y-4">
      <section className="rounded-lg border border-background-200 bg-background-50">
        <div className="border-b border-background-200 bg-gradient-to-r from-primary-50 to-accent-50 p-4">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            <div className="max-w-3xl">
              <div className="inline-flex items-center gap-1 rounded-full bg-background-50 px-2.5 py-1 text-[11px] font-bold text-primary-700">
                <i className="ri-map-pin-line"></i>
                Recommended jump
              </div>
              <h3 className="mt-2 font-heading text-lg font-semibold text-foreground-950">
                Need the full Maplemaps experience?
              </h3>
              <p className="mt-1 text-sm leading-relaxed text-foreground-700">
                This page keeps a local player-tool fallback. For the complete table, exact map images, and rotation reference, open Maplemaps directly.
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-2">
              <a
                href={MAPLEMAPS_TABLE_URL}
                target="_blank"
                rel="nofollow noopener noreferrer"
                className="h-11 px-5 rounded-md bg-primary-600 text-background-50 text-sm font-semibold hover:bg-primary-700 inline-flex items-center justify-center gap-2"
              >
                <i className="ri-external-link-line"></i>
                Open Maplemaps Table
              </a>
              <a
                href={MAPLEMAPS_WORLD_URL}
                target="_blank"
                rel="nofollow noopener noreferrer"
                className="h-11 px-4 rounded-md border border-background-200 bg-background-50 text-sm font-semibold text-foreground-800 hover:text-primary-700 inline-flex items-center justify-center gap-2"
              >
                <i className="ri-global-line"></i>
                World Map
              </a>
            </div>
          </div>
        </div>

        <div className="border-b border-background-200 p-4">
          <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-4">
            <div>
              <div className="text-sm font-semibold text-foreground-950">Select a Region:</div>
              <div className="mt-2 grid grid-cols-1 sm:grid-cols-3 gap-2">
                {regionOptions.map((region) => (
                  <button
                    key={region.key}
                    type="button"
                    onClick={() => {
                      setSelectedRegion(region.key);
                      setSelectedZone('all');
                      setSelectedMapName(null);
                    }}
                    className={`rounded-md border px-3 py-2 text-left cursor-pointer transition-colors ${
                      selectedRegion === region.key
                        ? 'border-primary-500 bg-primary-50 text-primary-800'
                        : 'border-background-200 bg-background-100 text-foreground-800 hover:border-primary-300'
                    }`}
                  >
                    <span className="block text-sm font-semibold">{region.label}</span>
                    <span className="mt-0.5 block text-[11px] text-foreground-500">{region.hint}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="h-9 px-4 rounded-md bg-foreground-900 text-background-50 text-sm font-semibold inline-flex items-center">
                Table View
              </span>
              <a
                href={MAPLEMAPS_TABLE_URL}
                target="_blank"
                rel="nofollow noopener noreferrer"
                className="h-9 px-3 rounded-md border border-background-200 bg-background-100 text-xs font-semibold text-foreground-700 hover:text-primary-700 inline-flex items-center gap-1"
              >
                maplemaps.net
                <i className="ri-external-link-line"></i>
              </a>
            </div>
          </div>
        </div>

        <WorldMapPanel
          region={selectedRegion}
          pins={mapPins}
          selectedZone={selectedZone}
          onSelectZone={(zone) => {
            setSelectedZone(zone);
            setSelectedMapName(null);
          }}
        />

        <div className="grid grid-cols-1 xl:grid-cols-[230px_minmax(0,1fr)_280px]">
          <aside className="border-b xl:border-b-0 xl:border-r border-background-200 bg-background-100 p-3">
            <div className="text-xs font-bold uppercase tracking-wider text-foreground-500">{currentRegion.label}</div>
            <div className="mt-3 space-y-1">
              {zones.map((zone) => {
                const count = zone === 'all' ? regionRows.length : regionRows.filter((row) => row.zone === zone).length;
                return (
                  <button
                    key={zone}
                    type="button"
                    onClick={() => {
                      setSelectedZone(zone);
                      setSelectedMapName(null);
                    }}
                    className={`w-full rounded-md px-3 py-2 text-left cursor-pointer flex items-center justify-between gap-2 ${
                      selectedZone === zone ? 'bg-primary-50 text-primary-800 font-semibold' : 'text-foreground-700 hover:bg-background-50'
                    }`}
                  >
                    <span className="truncate text-sm">{zone === 'all' ? 'All Maps' : zone}</span>
                    <span className="rounded-full bg-background-50 px-2 py-0.5 text-[10px] text-foreground-500">{count}</span>
                  </button>
                );
              })}
            </div>
          </aside>

          <main className="min-w-0 p-3 md:p-4">
            <div className="grid grid-cols-1 lg:grid-cols-[minmax(0,1fr)_140px_160px] gap-2">
              <div className="relative">
                <i className="ri-search-line absolute left-3 top-1/2 -translate-y-1/2 text-foreground-400"></i>
                <input
                  value={query}
                  onChange={(event) => setQuery(event.target.value)}
                  placeholder="Filter by name, zone, or mob level"
                  className="h-10 w-full rounded-md border border-background-300 bg-background-50 pl-9 pr-3 text-sm outline-none focus:border-primary-500"
                />
              </div>
              <label className="flex items-center gap-2 rounded-md border border-background-300 bg-background-50 px-3">
                <span className="text-xs font-semibold text-foreground-500">Level</span>
                <input
                  type="number"
                  value={level}
                  min={1}
                  max={300}
                  onChange={(event) => setLevel(Number(event.target.value) || 1)}
                  className="h-9 min-w-0 flex-1 bg-transparent text-sm font-semibold outline-none"
                />
              </label>
              <select
                value={sortKey}
                onChange={(event) => setSortKey(event.target.value as SortKey)}
                className="h-10 rounded-md border border-background-300 bg-background-50 px-3 text-sm outline-none focus:border-primary-500"
              >
                <option value="level">Sort: Level</option>
                <option value="exp">Sort: Exp/hr</option>
                <option value="meso">Sort: Meso/hr</option>
                <option value="spawn">Sort: Spawn</option>
                <option value="name">Sort: Map Name</option>
              </select>
            </div>

            <div className="mt-3 flex flex-wrap items-center gap-3 text-xs text-foreground-700">
              <label className="inline-flex items-center gap-1.5 cursor-pointer">
                <input type="checkbox" checked={showFrenzy} onChange={(event) => setShowFrenzy(event.target.checked)} className="accent-primary-600" />
                Show frenzy rates
              </label>
              <label className="inline-flex items-center gap-1.5 cursor-pointer">
                <input type="checkbox" checked={personalRates} onChange={(event) => setPersonalRates(event.target.checked)} className="accent-primary-600" />
                Personal rates based on character level
              </label>
              <span className="ml-auto text-foreground-500">
                {filteredRows.length === 1 ? t('mh_map_count_one', { count: filteredRows.length }) : t('mh_map_count_other', { count: filteredRows.length })}
              </span>
            </div>

            <div className="mt-2 flex flex-wrap items-center gap-2 text-[11px] text-foreground-500">
              <span className="rounded-full border border-background-200 bg-background-100 px-2 py-0.5">
                Database: {allMaps.length} maps
              </span>
              {isLoadingExpandedMaps && (
                <span className="rounded-full border border-primary-200 bg-primary-50 px-2 py-0.5 text-primary-700">
                  Loading MapleStory.io map list...
                </span>
              )}
              {mapLoadError && (
                <span className="rounded-full border border-secondary-200 bg-secondary-50 px-2 py-0.5 text-secondary-800">
                  Live map list unavailable, showing featured maps
                </span>
              )}
            </div>

            <MapTable
              rows={filteredRows}
              selectedName={selectedMapName || undefined}
              onSelect={(name) => setSelectedMapName((current) => (current === name ? null : name))}
              onNavigate={selectRelativeMap}
              onCollapse={() => setSelectedMapName(null)}
            />
          </main>

          <aside className="border-t xl:border-t-0 xl:border-l border-background-200 bg-background-100 p-3">
            {selectedMap ? (
              <MapPreview row={selectedMap} />
            ) : (
              <div className="rounded-md border border-dashed border-background-300 p-6 text-center text-sm text-foreground-500">
                {t('mh_map_filter_empty')}
              </div>
            )}
          </aside>
        </div>

        <div className="border-t border-background-200 bg-background-100 px-4 py-3 text-xs leading-relaxed text-foreground-500">
          Fan-made, non-commercial player tool. Map renders are provided through MapleStory.io using MapleStory game assets.
          MapleStory and related assets belong to Nexon.
        </div>
      </section>
    </div>
  );
}

function MapTable({
  rows,
  selectedName,
  onSelect,
  onNavigate,
  onCollapse,
}: {
  rows: TableRow[];
  selectedName?: string;
  onSelect: (name: string) => void;
  onNavigate: (direction: -1 | 1) => void;
  onCollapse: () => void;
}) {
  if (rows.length === 0) {
    return (
      <div className="mt-4 rounded-md border border-dashed border-background-300 bg-background-100 p-10 text-center text-sm text-foreground-500">
        No maps match the current table filters.
      </div>
    );
  }

  return (
    <div className="mt-4 overflow-x-auto rounded-md border border-background-200 bg-background-50">
      <table className="w-full min-w-[980px] text-sm">
        <thead className="bg-background-100 text-xs text-foreground-600">
          <tr>
            <th className="px-3 py-2 text-left">Image</th>
            <th className="px-3 py-2 text-left">Map Name</th>
            <th className="px-3 py-2 text-left">Region</th>
            <th className="px-3 py-2 text-left">Mob Lvl</th>
            <th className="px-3 py-2 text-left">Force</th>
            <th className="px-3 py-2 text-left">Spawn</th>
            <th className="px-3 py-2 text-left">Cap/gen</th>
            <th className="px-3 py-2 text-left">Exp/hr</th>
            <th className="px-3 py-2 text-left">Meso/hr</th>
            <th className="px-3 py-2 text-left">Hours/lvl</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-background-200">
          {rows.map((row) => {
            const isSelected = selectedName === row.name;

            return (
              <Fragment key={row.name}>
                <tr
                  className={isSelected ? 'bg-primary-50' : 'hover:bg-background-100'}
                >
                  <td className="px-3 py-2">
                    <button
                      type="button"
                      onClick={() => onSelect(row.name)}
                      className={`h-8 w-8 rounded-md border cursor-pointer inline-flex items-center justify-center ${
                        isSelected
                          ? 'border-primary-500 bg-primary-600 text-background-50'
                          : 'border-background-300 bg-background-50 text-primary-700 hover:bg-primary-50'
                      }`}
                      title={isSelected ? 'Collapse map image' : 'View map image'}
                    >
                      <i className={isSelected ? 'ri-arrow-up-s-line' : 'ri-image-line'}></i>
                    </button>
                  </td>
                  <td className="px-3 py-2">
                    <button type="button" onClick={() => onSelect(row.name)} className="text-left font-semibold text-foreground-950 hover:text-primary-700 cursor-pointer">
                      {row.mapName}
                    </button>
                  </td>
                  <td className="px-3 py-2 text-foreground-700">{row.zone}</td>
                  <td className="px-3 py-2 text-foreground-700">{row.avgLevel}</td>
                  <td className="px-3 py-2 text-foreground-700">{row.forceLabel}</td>
                  <td className="px-3 py-2 font-semibold text-foreground-900">{row.spawn}</td>
                  <td className="px-3 py-2 text-foreground-700">{row.capPerGen}</td>
                  <td className="px-3 py-2 font-semibold text-primary-700">{formatRate(row.expHour)}</td>
                  <td className="px-3 py-2 text-foreground-700">{formatRate(row.mesoHour)}</td>
                  <td className="px-3 py-2 text-foreground-700">{row.hoursLevel}</td>
                </tr>
                {isSelected && (
                  <ExpandedMapRow
                    row={row}
                    colSpan={10}
                    onPrevious={() => onNavigate(-1)}
                    onNext={() => onNavigate(1)}
                    onCollapse={onCollapse}
                  />
                )}
              </Fragment>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

function ExpandedMapRow({
  row,
  colSpan,
  onPrevious,
  onNext,
  onCollapse,
}: {
  row: TableRow;
  colSpan: number;
  onPrevious: () => void;
  onNext: () => void;
  onCollapse: () => void;
}) {
  const mobsPerHour = row.spawn * 360;
  const instancedMobsPerHour = Math.round(mobsPerHour * 1.03);
  const visibleMonsterCount = Math.min(monsterMarkerPositions.length, Math.max(12, row.spawn));

  return (
    <tr className="bg-background-50">
      <td colSpan={colSpan} className="p-0">
        <div className="relative overflow-hidden border-y border-primary-400 bg-white">
          <div className="relative min-h-[390px] overflow-hidden bg-foreground-950">
            <img
              src={row.image}
              alt={`${row.name} map preview`}
              className="absolute inset-0 h-full w-full object-cover object-center opacity-90"
              loading="lazy"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-transparent to-black/35"></div>

            {platformBands.map((platform) => (
              <div
                key={`${platform.left}-${platform.top}`}
                className="absolute h-4 rounded-full bg-[#2c302a]/75 shadow-[0_-5px_0_#4e7641,0_-8px_0_#82a85d]"
                style={{
                  left: `${platform.left}%`,
                  top: `${platform.top}%`,
                  width: `${platform.width}%`,
                }}
              />
            ))}

            <div className="absolute left-0 top-0 z-20 w-[210px] rounded-br-md border-b border-r border-foreground-400/40 bg-background-100/95 p-3 text-foreground-950 shadow-lg backdrop-blur-sm">
              <button
                type="button"
                onClick={onCollapse}
                className="absolute left-1/2 top-1 h-6 w-8 -translate-x-1/2 rounded-md text-lg leading-none text-foreground-800 hover:bg-background-200 cursor-pointer"
                aria-label="Collapse map image"
              >
                <i className="ri-arrow-up-s-line"></i>
              </button>
              <a
                href={MAPLEMAPS_TABLE_URL}
                target="_blank"
                rel="nofollow noopener noreferrer"
                className="mt-8 inline-flex max-w-[130px] items-center gap-2 text-sm font-semibold underline underline-offset-2 hover:text-primary-700"
              >
                <span className="truncate">{row.mapName}</span>
                <i className="ri-external-link-line shrink-0 text-lg"></i>
              </a>
              <dl className="mt-2 space-y-1 text-sm">
                <div className="flex justify-between gap-3">
                  <dt>Avg Level:</dt>
                  <dd className="font-semibold tabular-nums">{row.avgLevel}</dd>
                </div>
                <div className="flex justify-between gap-3">
                  <dt>Mobs/hr:</dt>
                  <dd className="font-semibold tabular-nums">{mobsPerHour.toLocaleString()}</dd>
                </div>
                <div className="flex justify-between gap-3">
                  <dt>Instanced:</dt>
                  <dd className="font-semibold tabular-nums">{instancedMobsPerHour.toLocaleString()}</dd>
                </div>
              </dl>
              <div className="mt-2 rounded border border-background-300 bg-background-50 px-2 py-1 text-[10px] font-semibold text-foreground-500">
                Game render via MapleStory.io
              </div>
            </div>

            {Array.from({ length: visibleMonsterCount }).map((_, index) => {
              const monster = row.monsters[index % row.monsters.length];
              const position = monsterMarkerPositions[index % monsterMarkerPositions.length];

              return (
                <div
                  key={`${monster}-${index}`}
                  className="absolute z-10 h-9 w-9 -translate-x-1/2 -translate-y-full drop-shadow-[0_3px_3px_rgba(0,0,0,.55)]"
                  style={{ left: `${position.x}%`, top: `${position.y}%` }}
                  title={monster}
                >
                  {monsterImages[monster] ? (
                    <img src={monsterImages[monster]} alt={monster} className="h-full w-full rounded-full object-cover object-top" loading="lazy" />
                  ) : (
                    <div className="h-full w-full rounded-full bg-foreground-900 text-background-50 grid place-items-center text-xs font-bold">
                      {monster.slice(0, 1)}
                    </div>
                  )}
                </div>
              );
            })}

            <div className="absolute left-[8%] top-[61%] h-14 w-10 rounded-full border-4 border-[#f4e6ad] bg-foreground-950/70 shadow-[0_0_18px_rgba(255,235,160,.95)]"></div>
            <div className="absolute right-[7%] top-[38%] h-14 w-10 rounded-full border-4 border-[#f4e6ad] bg-foreground-950/70 shadow-[0_0_18px_rgba(255,235,160,.95)]"></div>
            <div className="absolute bottom-4 left-[4%] h-11 w-8 rounded-full bg-sky-200/60 blur-sm"></div>
            <div className="absolute bottom-4 right-[12%] h-11 w-8 rounded-full bg-sky-200/60 blur-sm"></div>

            <button
              type="button"
              onClick={onPrevious}
              className="absolute left-3 top-1/2 h-11 w-11 -translate-y-1/2 rounded-full border border-background-200 bg-background-50/95 text-xl text-foreground-800 shadow-md hover:bg-background-100 cursor-pointer"
              aria-label="Previous map"
            >
              <i className="ri-arrow-left-line"></i>
            </button>
            <button
              type="button"
              onClick={onNext}
              className="absolute right-3 top-1/2 h-11 w-11 -translate-y-1/2 rounded-full border border-background-200 bg-background-50/95 text-xl text-foreground-800 shadow-md hover:bg-background-100 cursor-pointer"
              aria-label="Next map"
            >
              <i className="ri-arrow-right-line"></i>
            </button>
          </div>

          <div className="relative h-16 bg-background-50">
            <button
              type="button"
              onClick={onCollapse}
              className="absolute left-1/2 top-full h-8 w-16 -translate-x-1/2 -translate-y-full rounded-t-md border border-background-300 bg-background-50 text-xl text-foreground-700 shadow-sm hover:bg-background-100 cursor-pointer"
              aria-label="Collapse map image"
            >
              <i className="ri-arrow-up-s-line"></i>
            </button>
          </div>
        </div>
      </td>
    </tr>
  );
}

function WorldMapPanel({
  region,
  pins,
  selectedZone,
  onSelectZone,
}: {
  region: MajorRegion;
  pins: MapPin[];
  selectedZone: string;
  onSelectZone: (zone: string) => void;
}) {
  const title = regionOptions.find((item) => item.key === region)?.label || 'World Map';
  const labels = worldMapLabels[region];
  const regionTone = {
    maple: {
      sea: 'from-[#8dc8dc] via-[#9bc8d6] to-[#b7c2df]',
      frame: '#4b3627',
      title: 'Maple World',
    },
    arcane: {
      sea: 'from-[#6763af] via-[#7fb8d8] to-[#9dd6c8]',
      frame: '#3e315c',
      title: 'Arcane River',
    },
    grandis: {
      sea: 'from-[#d7b578] via-[#a9c8b6] to-[#93b8d6]',
      frame: '#51422d',
      title: 'Grandis',
    },
  }[region];

  return (
    <div className="border-b border-background-200 bg-background-100 p-3 md:p-4">
      <div className="mb-3 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
        <div>
          <div className="text-sm font-semibold text-foreground-950">World Map</div>
          <p className="text-xs text-foreground-500">Click a blue marker to filter the table by region.</p>
        </div>
        <button
          type="button"
          onClick={() => onSelectZone('all')}
          className={`h-8 px-3 rounded-md text-xs font-semibold cursor-pointer ${
            selectedZone === 'all' ? 'bg-primary-600 text-background-50' : 'bg-background-50 border border-background-200 text-foreground-700 hover:bg-primary-50'
          }`}
        >
          Show All Maps
        </button>
      </div>

      <div className="mx-auto max-w-5xl">
        <div className={`relative aspect-[16/9] overflow-hidden rounded-md border border-background-300 bg-gradient-to-br ${regionTone.sea} shadow-inner`}>
          <svg className="absolute inset-0 h-full w-full" viewBox="0 0 100 56" preserveAspectRatio="none" aria-hidden="true">
            <defs>
              <pattern id={`grid-${region}`} width="8" height="8" patternUnits="userSpaceOnUse">
                <path d="M 8 0 L 0 0 0 8" fill="none" stroke="rgba(255,255,255,.18)" strokeWidth=".18" />
              </pattern>
              <filter id={`soft-shadow-${region}`} x="-20%" y="-20%" width="140%" height="140%">
                <feDropShadow dx="0" dy="1.5" stdDeviation="1.2" floodColor="rgba(44,30,17,.32)" />
              </filter>
              <radialGradient id={`green-land-${region}`} cx="45%" cy="35%" r="70%">
                <stop offset="0%" stopColor="#cfe8a0" />
                <stop offset="55%" stopColor="#8fb678" />
                <stop offset="100%" stopColor="#547c57" />
              </radialGradient>
              <radialGradient id={`snow-land-${region}`} cx="50%" cy="40%" r="70%">
                <stop offset="0%" stopColor="#f5f2f0" />
                <stop offset="58%" stopColor="#d6d6df" />
                <stop offset="100%" stopColor="#9da6b6" />
              </radialGradient>
              <radialGradient id={`desert-land-${region}`} cx="50%" cy="45%" r="70%">
                <stop offset="0%" stopColor="#ead39b" />
                <stop offset="60%" stopColor="#c69a61" />
                <stop offset="100%" stopColor="#9b7145" />
              </radialGradient>
              <radialGradient id={`magic-land-${region}`} cx="50%" cy="45%" r="70%">
                <stop offset="0%" stopColor="#d6c4f0" />
                <stop offset="58%" stopColor="#9a8ed1" />
                <stop offset="100%" stopColor="#5c5b99" />
              </radialGradient>
            </defs>
            <rect width="100" height="56" fill="transparent" />
            <rect width="100" height="56" fill={`url(#grid-${region})`} />
            <path d="M3 5 H97 L95 52 H5 Z" fill="none" stroke={regionTone.frame} strokeWidth="1.25" />
            <path d="M4.3 6.2 H95.7 L93.9 50.7 H6.1 Z" fill="none" stroke="rgba(255,255,255,.35)" strokeWidth=".3" />

            <g opacity=".55">
              <path d="M3 12 C10 6 16 9 20 5 C26 0 33 5 38 3" fill="none" stroke="rgba(255,255,255,.55)" strokeWidth="1.3" strokeLinecap="round" />
              <path d="M68 6 C76 1 86 7 94 4" fill="none" stroke="rgba(255,255,255,.55)" strokeWidth="1.4" strokeLinecap="round" />
              <path d="M75 50 C83 45 90 52 96 47" fill="none" stroke="rgba(255,255,255,.38)" strokeWidth="1.2" strokeLinecap="round" />
            </g>

            {region === 'maple' && (
              <>
                <path d="M8 21 C12 14 18 13 23 18 C29 24 30 34 25 40 C18 47 8 42 5 34 C2 28 4 24 8 21Z" fill={`url(#green-land-${region})`} stroke="#526f53" strokeWidth=".75" filter={`url(#soft-shadow-${region})`} />
                <path d="M30 38 C36 30 47 26 57 30 C65 35 65 44 56 49 C46 55 32 52 28 45 C26 42 27 40 30 38Z" fill={`url(#green-land-${region})`} stroke="#526f53" strokeWidth=".75" filter={`url(#soft-shadow-${region})`} />
                <path d="M57 16 C66 9 81 9 91 19 C85 27 67 28 56 23 C52 21 53 18 57 16Z" fill="#b8ce8b" stroke="#7e8756" strokeWidth=".75" filter={`url(#soft-shadow-${region})`} />
                <path d="M56 31 C67 25 84 27 92 36 C84 46 66 48 55 40 C51 36 52 33 56 31Z" fill={`url(#desert-land-${region})`} stroke="#91754e" strokeWidth=".75" filter={`url(#soft-shadow-${region})`} />
                <path d="M36 13 C43 8 52 11 55 18 C50 24 39 24 34 18 C32 16 33 14 36 13Z" fill={`url(#snow-land-${region})`} stroke="#a5a3a5" strokeWidth=".7" filter={`url(#soft-shadow-${region})`} />
                <path d="M35 41 C42 36 50 37 55 43 C50 49 40 48 34 44Z" fill="#d5e77f" stroke="#849b48" strokeWidth=".7" filter={`url(#soft-shadow-${region})`} />
                <path d="M9 24 l2 -2 l1.5 4 l1.5 -5 l2 6 l1.5 -4 l2.5 5" fill="none" stroke="#355e35" strokeWidth=".75" />
                <path d="M31 45 C38 41 48 41 55 45" fill="none" stroke="#4f8a43" strokeWidth=".9" />
                <path d="M61 20 l2 -4 l2 5 l2 -4 l2 5" fill="none" stroke="#6e7948" strokeWidth=".8" />
                <path d="M63 36 C68 34 76 34 82 37" fill="none" stroke="#b67b42" strokeWidth=".9" />
              </>
            )}
            {region === 'arcane' && (
              <>
                <path d="M8 29 C15 16 31 16 38 28 C31 40 17 42 8 35Z" fill="#9ed18b" stroke="#4f7d45" strokeWidth=".75" filter={`url(#soft-shadow-${region})`} />
                <path d="M33 17 C46 7 63 15 65 29 C54 36 39 33 33 24Z" fill={`url(#magic-land-${region})`} stroke="#6750a0" strokeWidth=".75" filter={`url(#soft-shadow-${region})`} />
                <path d="M58 31 C69 22 88 27 93 39 C83 50 67 49 58 40Z" fill="#8ad1d3" stroke="#477d84" strokeWidth=".75" filter={`url(#soft-shadow-${region})`} />
                <path d="M32 40 C46 34 61 36 74 44 C65 53 44 54 32 47Z" fill="#6570b8" stroke="#383e78" strokeWidth=".75" filter={`url(#soft-shadow-${region})`} />
                <path d="M41 21 C45 18 52 18 58 21" fill="none" stroke="rgba(255,255,255,.58)" strokeWidth=".8" />
                <path d="M62 38 C69 35 80 37 88 40" fill="none" stroke="#4f9ca5" strokeWidth=".8" />
              </>
            )}
            {region === 'grandis' && (
              <>
                <path d="M8 16 C24 7 41 12 46 27 C34 36 17 33 7 25Z" fill={`url(#desert-land-${region})`} stroke="#8b7442" strokeWidth=".75" filter={`url(#soft-shadow-${region})`} />
                <path d="M38 31 C48 18 66 19 73 31 C65 45 48 46 38 38Z" fill="#a8bbdc" stroke="#556b8e" strokeWidth=".75" filter={`url(#soft-shadow-${region})`} />
                <path d="M66 15 C78 8 93 15 95 29 C85 36 72 34 64 25Z" fill="#97c981" stroke="#4f7d45" strokeWidth=".75" filter={`url(#soft-shadow-${region})`} />
                <path d="M61 38 C74 33 91 39 94 49 C82 55 68 53 60 46Z" fill="#e0d0a1" stroke="#8b7442" strokeWidth=".75" filter={`url(#soft-shadow-${region})`} />
                <path d="M22 34 C32 29 43 34 44 44 C35 50 23 47 20 41Z" fill="#e6d46f" stroke="#9b8736" strokeWidth=".7" filter={`url(#soft-shadow-${region})`} />
                <path d="M15 22 C23 18 33 20 41 26" fill="none" stroke="#a6783d" strokeWidth=".9" />
                <path d="M67 24 C75 21 84 24 91 28" fill="none" stroke="#5a8b51" strokeWidth=".85" />
                <path d="M66 45 C74 41 84 44 91 48" fill="none" stroke="#b28d57" strokeWidth=".85" />
              </>
            )}
          </svg>

          <div className="absolute left-1/2 top-5 z-20 -translate-x-1/2 rounded-md border border-[#8b5f30] bg-[#e7c57a] px-5 py-2 text-center shadow-md">
            <div className="font-heading text-lg font-semibold text-[#5a3518]">{regionTone.title || title.replace(' Region', '')}</div>
          </div>

          {labels.map((label) => (
            <div
              key={label.label}
              className={`absolute z-10 -translate-x-1/2 -translate-y-1/2 rounded-sm border px-2 py-0.5 text-[10px] font-bold shadow-sm ${
                label.tone === 'light'
                  ? 'border-background-50/40 bg-foreground-800/80 text-background-50'
                  : 'border-[#8b5f30]/70 bg-[#f8dfaa]/95 text-[#5a3518]'
              }`}
              style={{ left: `${label.x}%`, top: `${label.y}%` }}
            >
              {label.label}
            </div>
          ))}

          {pins.map((pin) => (
            <button
              key={pin.zone}
              type="button"
              onClick={() => onSelectZone(pin.zone)}
              className={`absolute z-20 h-4 w-4 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-background-50 shadow-md cursor-pointer ${
                selectedZone === pin.zone ? 'bg-secondary-500 ring-4 ring-secondary-300/50' : 'bg-primary-500 hover:bg-primary-600'
              }`}
              style={{ left: `${Math.min(96, pin.x + 2)}%`, top: `${Math.max(7, pin.y - 1.8)}%` }}
              title={`${pin.zone} (${pin.count})`}
              aria-label={`${pin.zone} map marker`}
            >
              <span className="sr-only">{pin.zone}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

function MapPreview({ row }: { row: TableRow }) {
  return (
    <div className="space-y-3">
      <div>
        <div className="text-[11px] font-bold uppercase tracking-wider text-foreground-500">Map Image</div>
        <h3 className="mt-1 font-heading text-base font-semibold text-foreground-950">{row.mapName}</h3>
        <p className="text-xs text-foreground-500">{row.zone}</p>
      </div>
      <img src={row.image} alt={row.name} className="h-40 w-full rounded-md border border-background-200 object-cover object-top" loading="lazy" />
      {'imageSource' in row && (
        <div className="rounded-md border border-background-200 bg-background-50 px-2 py-1 text-[10px] font-semibold text-foreground-500">
          {row.imageSource}
        </div>
      )}
      <div className="grid grid-cols-2 gap-2 text-xs">
        <Stat label="Mob Lvl" value={String(row.avgLevel)} />
        <Stat label="Spawn" value={String(row.spawn)} />
        <Stat label="Cap/gen" value={String(row.capPerGen)} />
        <Stat label="Force" value={row.forceLabel} />
        <Stat label="Exp/hr" value={formatRate(row.expHour)} />
        <Stat label="Meso/hr" value={formatRate(row.mesoHour)} />
      </div>
      <div>
        <div className="text-[11px] font-bold uppercase tracking-wider text-foreground-500">Monsters</div>
        <div className="mt-2 space-y-2">
          {row.monsters.map((monster) => (
            <div key={monster} className="flex items-center gap-2 rounded-md border border-background-200 bg-background-50 p-2 text-xs font-semibold text-foreground-800">
              {monsterImages[monster] && <img src={monsterImages[monster]} alt={monster} className="h-8 w-8 rounded object-cover object-top" loading="lazy" />}
              {monster}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border border-background-200 bg-background-50 p-2">
      <div className="text-[10px] uppercase text-foreground-500">{label}</div>
      <div className="mt-1 font-semibold text-foreground-950">{value}</div>
    </div>
  );
}
